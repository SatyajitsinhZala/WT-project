export const DB_CONNECT = "mongodb+srv://Satyajit:t9VQBeV_b2eC*nb@cluster0.imfli.mongodb.net/"

export const JWT_TOKEN_SECRET = "sjafflamieakmddvad";

export const statusCode = {
    SUCCESS: 200,
    VALIDATION_ERROR: 201,
    UNPROCESSABLE_ENTITY: 202,
    AUTH_ERROR: 203
}